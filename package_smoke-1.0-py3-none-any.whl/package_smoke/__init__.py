answer = 42
